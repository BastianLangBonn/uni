function [ fitness ] = evaluationFunction( p )
%EVALUATIONFUNCTION Summary of this function goes here
%   Detailed explanation goes here
    fitness = rastr(p.points');

end

